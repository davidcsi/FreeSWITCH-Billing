#!/usr/bin/perl

use strict;
use warnings;
use DBI;
$|=1;

sub ReCreateXMLFiles();
sub ReCreateXMLFilesOnly();
sub ResetReload();

my $gateway=shift;
my $type=shift;

if(!defined($gateway)){
	print "ERROR: You must specify a gateway to reload\n";
	exit -1;
}

my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
my $result;
my $command="";
my $data="";


print "gw: $gateway - type: $type\n";
###            IF TYPE IR "ROUTE", DO A SIMPLE "distributor_ctl reload", ELSE DO NORMAL RELOAD WITH XML AND ALL
if(defined($type) && $type =~ m/ROUTE/){

     ReCreateXMLFiles();
	
     $command = "/usr/local/freeswitch/bin/fs_cli -x 'reloadxml'";
     $data=`$command`;
     print "distReload: $data\n";

     $command = "/usr/local/freeswitch/bin/fs_cli -x 'distributor_ctl reload'";
     $data=`$command`;
     print "distReload: $data\n";

     $data="";
     $command = "/usr/local/freeswitch/bin/fs_cli -x 'distributor " . $gateway . "'";
     print "distRouteList: $data\n";

     while($data=~m/-err/ && $type !~ m/ROUTE/){
          $command = "/usr/local/freeswitch/bin/fs_cli -x 'distributor " . $gateway . "'";
          $data=`$command`;
          print "distRouteList: $data\n";
     }

}elsif(defined($type) && $type =~ m/XML/){

     ReCreateXMLFilesOnly();

}else{
     
     my $sth_trace = $dbh->prepare("select service_type from ws_settings;");
     $sth_trace->execute();
     while($result = $sth_trace->fetchrow_hashref()){
          print "PROFILE: " . $result->{service_type} . "\n";
     
     
               print "GATEWAY: " . $gateway . "  ->  api sofia profile " . $result->{service_type} . " killgw " . $gateway . "\n";
     
               $command = "/usr/local/freeswitch/bin/fs_cli -x 'sofia profile " . $result->{service_type} . " killgw " . $gateway . "'";
               $data=`$command`;
               print "gwKill: $data\n";
     
               ReCreateXMLFiles();
               ResetReload();          
     
               $command = "/usr/local/freeswitch/bin/fs_cli -x 'sofia profile " . $result->{service_type} . " rescan'";
               $data=`$command`;
               $command = "/usr/local/freeswitch/bin/fs_cli -x 'sofia profile " . $result->{service_type} . " gwlist'";
               $data=`$command`;
     
               while(!($data =~ m/$gateway/)){
                    $command = "/usr/local/freeswitch/bin/fs_cli -x 'sofia profile " . $result->{service_type} . " gwlist'";
                    $data=`$command`;
                    print "gwList(1): $data\n";
          		sleep 1;
               }
     }
}


exit 0;

sub ReCreateXMLFiles(){
     system("wget --quiet http://viking_db/fsxml/sofia.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/sofia.conf.xml") == 0 or die "Couldn't get sofia.conf.xml!";
     system("wget --quiet http://viking_db/fsxml/distributor.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/distributor.conf.xml") == 0 or die "Couldn't get distributor.conf.xml!";
     system("wget --quiet http://viking_db/fsxml/dialplan.conf.php --output-document=/usr/local/freeswitch/conf/dialplan/default.conf.xml") == 0 or die "Couldn't get Dialplan!";
     
     my $command = "/usr/local/freeswitch/bin/fs_cli -x 'reload mod_distributor'";
     system($command) == 0 or die "Couldn't reload mod_distributor!";
      
     $command = "/usr/local/freeswitch/bin/fs_cli -x 'reloadxml'";
     system($command) == 0 or die "Couldn't reload mod_distributor!";

     return;
}

sub ResetReload(){
     my $sth_trace = $dbh->prepare("update ws_settings set reload = 'NO';");
     $sth_trace->execute();
     
     return;
}

sub ReCreateXMLFilesOnly(){
     system("wget --quiet http://viking_db/fsxml/sofia.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/sofia.conf.xml") == 0 or die "Couldn't get sofia.conf.xml!";
     system("wget --quiet http://viking_db/fsxml/distributor.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/distributor.conf.xml") == 0 or die "Couldn't get distributor.conf.xml!";
     system("wget --quiet http://viking_db/fsxml/dialplan.conf.php --output-document=/usr/local/freeswitch/conf/dialplan/default.conf.xml") == 0 or die "Couldn't get Dialplan!";

     $command = "/usr/local/freeswitch/bin/fs_cli -x 'reloadxml'";
     system($command) == 0 or die "Couldn't reload XML!";

     return;
}
