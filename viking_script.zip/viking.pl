#!/usr/bin/perl

require ESL;
ESL::eslSetLogLevel(7);

use IO::Socket::INET;
use strict;
use warnings;
use DBI;
use Switch;
$|=1;

sub GetCustomerSettings();
sub DBConnect();
sub setVars();
sub Disconnect($);

#ESL::eslSetLogLevel(7);

my $ip = "127.0.0.1";
my $sock = new IO::Socket::INET ( 
     LocalHost => $ip,  
     LocalPort => '8040',  
     Proto => 'tcp',  
     Listen => 1,  
     Reuse => 1 
);
my $e;
my $con;
my $ClgNum;
my $CldNum;
my $Context;
my $ClgIP;
my $ClgUser;
my $info;
my $uuid;
my $fd;
my $host;
my $dbh;
my $new_sock;
############################  CUSTOMER-RELATED VARIABLES
my $CustID;
my $CustCompany;
my $CustSymbol;
my $CustSignallingIP;
my $CustRateTable;
my $CustPrepaid;
my $CustBalance;
my $CustEnabled;
my $CustMaxCalls;
############################

# Connect to DB
DBConnect();
die "Could not create socket: $!\n" unless $sock;

for(;;) {
     my $new_sock = $sock->accept();
     my $pid = fork();
     if ($pid) {
          close($new_sock);
          next;
     }

     $host = $new_sock->sockhost();
     $fd = fileno($new_sock);     
     $con = new ESL::ESLconnection($fd);
     $info = $con->getInfo();
     $uuid = $info->getHeader("unique-id");

     printf "Connected call %s, from %s\n", $uuid, $info->getHeader("caller-caller-id-number");
     
     $e = $con->filter("unique-id", $uuid);

     if ($e) { print "<" . $e->serialize() . ">"; } else { printf("WTF?\n"); }
     
     $con->events("plain", "CHANNEL_DATA SOCKET_DATA SESSION_HEARTBEAT CHANNEL_ANSWER CHANNEL_ORIGINATE CHANNEL_PROGRESS CHANNEL_HANGUP CHANNEL_BRIDGE CHANNEL_UNBRIDGE CHANNEL_OUTGOING CHANNEL_EXECUTE CHANNEL_EXECUTE_COMPLETE DTMF");
     $con->sendRecv("linger");
     
     while($con->connected()) {
        print "Connected\n";
        print "EVENT <".$e->getHeader("event-name").">\n";
        #my $e = $con->recvEventTimed(1000);
        my $e = $con->recvEvent();

        if ($e) {
            my $name = $e->getHeader("event-name");
            print "EVENT [$name]\n";

            ############### NEW INCOMING CALL ###############
            if ($name eq "CHANNEL_CALLSTATE" || $name eq "SOCKET_DATA" || $name eq "CHANNEL_DATA") {
                 print "--> NEW CALL\n";
                 setVars();
                 Disconnect("NO_ROUTE_DESTINATION") if !GetCustomerSettings();
                 print "We got the customer's data\n";
                 $con->api("limit","hash inbound $ClgIP 2 !USER_BUSY");
                 $con->execute("answer");
                 for(;;){ }
            }
        }
        print "Out-ot-if\n";
     }
     
     print "BYE\n";
     close($new_sock);
}


sub setVars(){
     $ClgNum    = $info->getHeader("Channel-Caller-ID-Number");
     $CldNum    = $info->getHeader("Caller-Destination-Number");
     $Context   = $info->getHeader("Caller-Context");
     $ClgIP     = $info->getHeader("Channel-Network-Addr");
     $ClgUser   = $info->getHeader("variable_sip_from_user");

    print "Vars: 
    ClgNum  : $ClgNum
    CldNum  : $CldNum
    Context : $Context
    ClgIP   : $ClgIP
    ClgUser : $ClgUser
\n";

     #$con->execute("answer");
}

sub DBConnect(){
     $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
}

sub Disconnect( $ ){
    my $reason = shift;

    print "BYE ($reason)\n";
    #$con->api("hangup",$reason);
    
    $con->execute("api uuid_kill $uuid $reason");
    print "api uuid_kill $uuid $reason\n";
#    close($new_sock);
}

sub GetCustomerSettings(){
    my $result = 0;
    my $sql = " select 
                    ws_customer_id, 
                    ws_customer_company, 
                    ws_customer_symbol, 
                    ws_customer_sig_ip, 
                    ws_customer_ratetable, 
                    ws_customer_prepaid, 
                    ws_customer_balance, 
                    ws_customer_enabled, 
                    ws_customer_max_calls 
                from 
                    ws_customers 
                where 
                    ws_customer_sig_ip like '%$ClgIP%' and 
                    ws_customer_context='$Context' and ws_customer_enabled=1;";
    print "SQL: $sql\n";
    
    my $sth = $dbh->prepare($sql);
    $sth->execute();
    while(my $ref = $sth->fetchrow_hashref())
    {
        $CustID             = $ref->{ws_customer_id};
        $CustCompany        = $ref->{ws_customer_company}; 
        $CustSymbol         = $ref->{ws_customer_symbol}; 
        $CustSignallingIP   = $ref->{ws_customer_sig_ip}; 
        $CustRateTable      = $ref->{ws_customer_ratetable}; 
        $CustPrepaid        = $ref->{ws_customer_prepaid}; 
        $CustBalance        = $ref->{ws_customer_balance}; 
        $CustEnabled        = $ref->{ws_customer_enabled}; 
        $CustMaxCalls       = $ref->{ws_customer_max_calls};
        $result = 1;
    }
    return $result;
}

