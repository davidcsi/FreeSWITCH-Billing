#!/usr/bin/perl

use strict;
use warnings;
use DBI;
$|=1;

sub Reload();
sub ResetReload();


my $dbh = DBI->connect('DBI:mysql:viking;host=192.168.168.2', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
my $result;
my $command="";
my $data="";

while(1){
     my $sth_trace = $dbh->prepare("select reload from ws_settings;");
     $sth_trace->execute();

     while($result = $sth_trace->fetchrow_hashref()){
          if($result->{reload} eq "YES"){
               Reload();
               ResetReload();
          }
     }

     print "waiting...\n";
     sleep 30;
}

exit 0;



sub Reload(){
     system("wget --quiet http://192.168.168.2:88/fsxml/sofia.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/sofia.conf.xml") == 0 or die "Couldn't get sofia.conf.xml!";
     system("wget --quiet http://192.168.168.2:88/fsxml/distributor.conf.php --output-document=/usr/local/freeswitch/conf/autoload_configs/distributor.conf.xml") == 0 or die "Couldn't get distributor.conf.xml!";
     system("wget --quiet http://192.168.168.2:88/fsxml/dialplan.conf.php --output-document=/usr/local/freeswitch/conf/dialplan/default.conf.xml") == 0 or die "Couldn't get Dialplan!";
     
     $command = "/usr/local/freeswitch/bin/fs_cli --host=192.168.168.3 --port=8021 --password=M3ll4m0d4v1d -x 'reload mod_distributor'";
     system($command) == 0 or die "Couldn't reload mod_distributor!";
      
     $command = "/usr/local/freeswitch/bin/fs_cli --host=192.168.168.3 --port=8021 --password=M3ll4m0d4v1d -x 'reloadxml'";
     system($command) == 0 or die "Couldn't reload mod_distributor!";

     return;
}

sub ResetReload(){
     my $sth_trace = $dbh->prepare("update ws_settings set reload = 'NO';");
     $sth_trace->execute();
     
     return;
}
