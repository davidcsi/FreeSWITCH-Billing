#!/usr/bin/perl
use DBI;
use strict;
use Digest::MD5 qw(md5_hex);

sub CheckSum();
sub CheckSumRoutes();
sub CheckSumGeneralConfig();

my $table_checksum = 0;
my $old_table_checksum = 0;
open LOG,">>","/opt/fs-viking/reload_check.log";

select(LOG); $| = 1; # make unbuffered
select(STDOUT); $| = 1; # make unbuffered

while(1){

     print LOG "Executing check and reload... \n";
     if(CheckSum()==1){
          print LOG "We just reloaded the Providers\n";
     }
     if(CheckSumRoutes()==1){
          print LOG "We just reloaded the Routes\n";
     }
     if(CheckSumGeneralConfig()==1){
          print LOG "We just reloaded the Routes\n";
     }

     sleep 10;
}

exit 0;





sub CheckSum(){
     my $change =0;
     my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
     my $sth = $dbh->prepare("select symbol from ws_providers where lastchange>'0000-00-00 00:00:00';") or die "Couldn't prepare statement: " . $dbh->errstr;
     $sth->execute();
     my $checksum;
     while (my @data = $sth->fetchrow_array()) {
          system("/opt/fs-viking/freeswitch_reload_config.pl $data[0]");
          $change=1;

          my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
          my $sth = $dbh->prepare("update ws_providers set lastchange = '0000-00-00 00:00:00';") or die "Couldn't prepare statement: " . $dbh->errstr;
          $sth->execute();
     }
     return $change;
}

sub CheckSumRoutes(){
     my $change =0;
     my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
     my $sth = $dbh->prepare("select route_name from ws_routes where lastchange>'0000-00-00 00:00:00';") or die "Couldn't prepare statement: " . $dbh->errstr;
     $sth->execute();
     my $checksum;
     while (my @data = $sth->fetchrow_array()) {
          system("/opt/fs-viking/freeswitch_reload_config.pl $data[0] ROUTE");
          $change=1;
          
          my $dbh2 = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
          my $sth2 = $dbh2->prepare("update ws_routes set lastchange = '0000-00-00 00:00:00';") or die "Couldn't prepare statement: " . $dbh->errstr;
          $sth2->execute();
          $dbh2 = undef;
          $sth2 = undef;
     }
     return $change;
}

sub CheckSumGeneralConfig(){
     my $change =0;
     my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
     my $sth = $dbh->prepare("select reload from ws_settings;") or die "Couldn't prepare statement: " . $dbh->errstr;
     $sth->execute();
     my $checksum;
     while (my @data = $sth->fetchrow_array()) {
	if($data[0] eq 'YES'){
	         system("/opt/fs-viking/freeswitch_reload_config.pl $data[0] XML");
	         $change=1;

	         my $dbh = DBI->connect('DBI:mysql:viking;host=viking_db', 'viking', 'V1k1ng') || die "Could not connect to database: $DBI::errstr";
	         my $sth = $dbh->prepare("update ws_settings set reload = 'NO';") or die "Couldn't prepare statement: " . $dbh->errstr;
         	$sth->execute();
	}
     }
     return $change;
}

