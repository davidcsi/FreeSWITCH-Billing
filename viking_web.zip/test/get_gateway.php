<html>
<body>
<form name="myform" method="post">
<?php
require_once('ESL.php');

if(isset($_GET['gw']) && $_GET['gw']>''){      
    $command = "sofia xmlstatus gateway " . $_GET['gw'];
    printf("Command to run is: %s\n", $command);

    $sock = new ESLconnection('192.168.168.3', '8021', 'M3ll4m0d4v1d');
    $res = $sock->api($command);
    $response = $res->getBody();
    
    $response = preg_replace("/\<\/.*\>/","%REPLACE%",$response);
    $response = preg_replace("/\<(.*?)\>/","\${1}: ",$response);
    $response = preg_replace("/%REPLACE%/","<br>",$response);
    printf("%s\n", $response);
}else{
    $command = "sofia profile gold gwlist";
    printf("GATEWAY LIST:<br>");

    $sock = new ESLconnection('192.168.168.3', '8021', 'M3ll4m0d4v1d');
    $res = $sock->api($command);
    $response = $res->getBody();
    
    $gws = explode(' ',$response);
foreach ($gws as $value){
    printf("<input id='gw' type=button onClick=\"window.location='get_gateway.php?gw=" . $value ."'\" value='%s' />\n", $value);
}
#    $response = preg_replace("/\<\/.*\>/","%REPLACE%",$response);
#    $response = preg_replace("/\<(.*?)\>/","\${1}: ",$response);
#    $response = preg_replace("/%REPLACE%/","<br>",$response);
    
}
?>
</form>
</body>
</html>