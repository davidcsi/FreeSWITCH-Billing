<?
function SQLResultTable($host,$user,$pass,$db,$Query)
{

     $link = mysql_connect ($host,$user,$pass) or die ('Could not connect: ' . mysql_error ());      //build MySQL Link
     mysql_select_db ($db) or die ('Could not select database');        //select database
     $Table = "";  //initialize table variable
     
     $Table.= "<table border='1' style=\"border-collapse: collapse;\">"; //Open HTML Table

     $Result = mysql_query ($Query); //Execute the query
     if(mysql_error ())
     {
          $Table.= "<tr><td>MySQL ERROR: " . mysql_error () . "</td></tr>";
     }
     else
     {
#          $RowBackColor = "#00CCCC";
          $RowBackColor = "#99CCFF";
          //$RowBackColorAlt = "#0099CC";
          $RowBackColorAlt = "#FFFFCC";
          $ForeColor = "#FFFFFF";
//          $RowForeColor = "#0066FF";
//          $RowForeColorAlt = "#0066FF";
          $RowForeColor = "#000099";
          $RowForeColorAlt = "#000099";
          
          
          //Header Row with Field Names
          $NumFields = mysql_num_fields ($Result);
          $Table.= "<tr style=\"background-color: #000066; color: $ForeColor;\">";
          for ($i=0; $i < $NumFields; $i++)
          {
               $Table.= "<th>" . mysql_field_name ($Result, $i) . "</th>"; 
          }
          $width = 100/($NumFields+1);
          $Table.= "</tr>";
          
          //Loop thru results
          $RowCt = 0; //Row Counter
          while($Row = mysql_fetch_assoc ($Result))
          {
               //Alternate colors for rows
               if($RowCt++ % 2 == 0) $Style = "background-color: $RowBackColor; color: $RowForeColor;";
               else $Style = "background-color: $RowBackColorAlt; color: $RowForeColorAlt;";
               
               $Table.= "<tr style=\"$Style\">";
               //Loop thru each field
               $fieldnum=0;
               foreach($Row as $field => $value)
               {
                    if( mysql_field_type($Result, $fieldnum)=="real"){
                         $alignment="right";
                         $campo = number_format($value, 4, ',', '.'); 
                    }elseif(mysql_field_type($Result, $fieldnum)=="int" ){ 
                         $alignment="right";
                         $campo = number_format($value, 0, ',', '.'); 
                    }else{ 
                         $alignment = "left";
                         $wrap = "NOWRAP";
                         $campo = $value; 
                    }
                    #$Table.= "<td width='$width%' align='$alignment'>$value</td>";
                    $Table.= "<td width='$width%' align='$alignment' $wrap>$campo</td>";
                    $fieldnum++;
               }
                    $Table.= "</tr>";
          }
          $Table.= "<tr style=\"background-color: #000066; color: #FFFFFF;\"><td colspan='$NumFields'>Query Returned " . mysql_num_rows ($Result) . " records</td></tr>";
     }
     $Table.= "</table>";
     
     return $Table;
}


?>