<?PHP

function displayLogin() {
header("WWW-Authenticate: Basic realm=\"Viking Management Platform\"");
header("HTTP/1.0 401 Unauthorized");
echo "<h2>Authentication Failure</h2>";
echo "La contrase�a que ha introducido no es v�lida. Refresque la p�gina e int�ntelo de nuevo.";
exit;

}

require "conexion.inc";
require "checklogin.inc";

$host="192.168.168.2";
$user="viking";
$pass="V1k1ng";
$db="viking";

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
	<title>Reporte por cliente</title>
	<link rel="stylesheet" href="pages_style.css">
</head>
<script type="text/javascript" src="calendarDateInput.js">

/***********************************************
* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
* Script featured on and available at http://www.dynamicdrive.com
* Keep this notice intact for use.
***********************************************/
</script>

<script type="text/javascript">
function Activation(obj)
{
     var bDisable;
     var chosenoption=this.options[this.selectedIndex]
     window.alert(chosenoption.value);
}
</script>
<body>
<h3>Cambiar Precio</h3>
<form action="changerates.php" method="post">
<?

     if ($_SERVER['REQUEST_METHOD'] != 'POST') {
?>
<table width=600px>
     <tr>
          <td>
               Descripcion:
          </td>
          <td>
               <input type="text" disabled="disabled" name="by_id" id="by_id" value="<?php echo $_GET['id']; ?>"/>
          </td>
     </tr>
     <tr>
          <td>
               Precio actual:
          </td>
          <td>
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select rate from " . $_GET['ratetable'] . " where " . $_GET['by'] . " = '" . $_GET['id'] . "' group by rate;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    
                    if( mysql_num_rows($resultado) > 1 ){  
                         echo "<input type='text' size='50' disabled='disabled' name='oldrate' value='MULTIPLES VALORES, NO SE PUEDE CAMBIAR!' wrap/>\n";
                    }else{
                         $newval=0;
                         while($linea=mysql_fetch_row($resultado)){                    	
                         	echo "<input type='text' disabled='disabled' id='oldrate' name='oldrate' value='" . $linea[0] . "'/>\n";
                         	$newval=$linea[0];
                         }
                    }
               ?>
          </td>
          <td nowrap>
               Nuevo Precio:
          </td>
          <td nowrap>
               <input type="text" name="newrate" id="newrate" value="<?php echo $newval; ?>"/>
          </td>
     </tr>
     <tr>
          <td>
               Ruta actual:
          </td>
          <td>
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select route from " . $_GET['ratetable'] . " where " . $_GET['by'] . " = '" . $_GET['id'] . "' group by rate;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    
                    if( mysql_num_rows($resultado) > 1 ){  
                         echo "<input type='text' size='50' disabled='disabled' name='oldrate' value='MULTIPLES VALORES, NO SE PUEDE CAMBIAR!' wrap/>\n";
                    }else{
                         $newval=0;
                         while($linea=mysql_fetch_row($resultado)){                    	
                         	echo "<input type='text' disabled='disabled' id='oldrate' name='oldrate' value='" . $linea[0] . "'/>\n";
                         	$newroute=$linea[0];
                         }
                    }
               ?>
          </td>
          <td nowrap>
               Nueva ruta:
          </td>
          <td nowrap>
               <select name="newroute" id="newroute">
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select route_name from ws_routes order by route_name;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    
                    while($linea=mysql_fetch_row($resultado)){ 
                         if($linea[0]==$newroute){ $var = "SELECTED"; }else{ $var = ""; } 
                    	echo "<option value='" . $linea[0] . "' $var>" . $linea[0] . "</option>\n";
                    }
               ?>
               </select>


          </td>
     </tr>
     <tr>
          <td>
               Fecha:
          </td>
          <td nowrap>
               <script>
                    DateInput('activate_date', true, 'YYYY-MM-DD')
               </script>
          </td>
     </tr>
     <tr>
          <td>
               Fecha:
          </td>
          <td nowrap>
               <select name="activate_hour" id="activate_hour">
                    <option>00</option>
                    <option>01</option>
                    <option>02</option>
                    <option>03</option>
                    <option>04</option>
                    <option>05</option>
                    <option>06</option>
                    <option>07</option>
                    <option>08</option>
                    <option>09</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
               </select>:00:00
          </td>
     </tr>
     <tr>
          <td>
               <input type="submit" name="submit" value="Ejecuta">
          </td>
     </tr>
</table>
<input type="text"  name="ratetable" id="ratetable" value="<?php echo $_GET['ratetable']; ?>"hidden>
<input type="text"  name="byid" id="byid" value="<?php echo $_GET['id']; ?>"hidden>

<?

     }else{

          $sqldatetime = "insert " . $_POST['ratetable'] . " select areacode, description, " . $_POST["newrate"] . ", '" . $_POST["newroute"] . "', '" . $_POST["activate_date"] . " " . $_POST["activate_hour"] . ":00:00' from " . $_POST['ratetable'] . " where description = '" . $_POST['byid'] . "'  group by areacode";
     //print "SQL: $sqldatetime <br>";
          if(!mysql_query($sqldatetime)){
               echo "<table width='100%''>
                    <tr>
                         <td>
                              Hubo un error insertanto los precios, por favor verifique los datos e int�ntelo de nuevo!<br>Admin info: " . mysql_error() . "
                         </td>
                    </tr>
               </table>";
          
          }else{
               echo "<table width='100%''>
                    <tr style='background: yellow; color: Blue'>
                         <td>
                              Los precios han sido introducidos correctamente.
                         </td>
                    </tr>
               </table>";
          }

     }
?>
</form>
</Body>
</html>
