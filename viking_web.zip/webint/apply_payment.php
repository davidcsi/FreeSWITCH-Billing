<?PHP

function displayLogin() {
header("WWW-Authenticate: Basic realm=\"Viking Management Platform\"");
header("HTTP/1.0 401 Unauthorized");
echo "<h2>Authentication Failure</h2>";
echo "La contrase�a que ha introducido no es v�lida. Refresque la p�gina e int�ntelo de nuevo.";
exit;

}

require "conexion.inc";
require "checklogin.inc";

$host="192.168.168.2";
$user="viking";
$pass="V1k1ng";
$db="viking";

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
	<title>Reporte por cliente</title>
	<link rel="stylesheet" href="pages_style.css">
</head>
<script type="text/javascript" src="calendarDateInput.js">

/***********************************************
* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
* Script featured on and available at http://www.dynamicdrive.com
* Keep this notice intact for use.
***********************************************/
</script>
<body>
<h3>Applicar pago de cliente</h3>
<form action="apply_payment.php" method="post">
<?

     if ($_SERVER['REQUEST_METHOD'] != 'POST') {
?>
<table width=600px>
     <tr>
          <td>
               Cliente:
          </td>
          <td>
               <input type="text" disabled="disabled" name="customer1" id="customer1" value="<?php echo $_GET['customer']; ?>"/>
          </td>
     </tr>
     <tr>
          <td>
               balance actual:
          </td>
          <td>
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select ws_customer_balance from ws_customers where ws_customer_symbol = '" . $_GET['customer'] . "' order by ws_customer_symbol desc limit 1;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    
                    while($linea=mysql_fetch_row($resultado)){                    	
                    	echo "<input type='text' disabled='disabled' id='oldbal' name='oldbal' value='" . $linea[0] . "'/>\n";
                    	$newval=$linea[0];
                    }
               ?>
          </td>
          <td nowrap>
               Aplicar pago:
          </td>
          <td nowrap>
               <input type="text" name="newpayment" id="newpayment" value="<?php echo $newval; ?>"/>
          </td>
     </tr>
     <tr>
          <td>
               <input type="submit" name="submit" value="Ejecuta">
          </td>
     </tr>
</table>
<input type="text"  name="customer" id="customer" value="<?php echo $_GET['customer']; ?>" hidden>
<input type="text"  name="oldbal" id="oldbal" value="<?php echo $newval; ?>" hidden>

<?

     }else{
#print('<pre>');
#print_r($_POST);
#print('</pre>');
          $sqldatetime = "update ws_customers set ws_customer_balance=ws_customer_balance+" . $_POST['newpayment'] . " where ws_customer_symbol = '" . $_POST['customer'] . "'";
          $payment_log = "insert accounting_log values (null,now(),'" . $_SERVER["PHP_AUTH_USER"] . "','" . $_POST['customer'] . "'," . $_POST['oldbal'] . "," . $_POST['newpayment'] . "," .  ($_POST['oldbal']+$_POST['newpayment']) . ");";

#print "SQL: $sqldatetime <br>";
#print "SQL: $payment_log <br>";


          if(mysql_query($payment_log)){
               if(!mysql_query($sqldatetime)){
                    echo "<table width='100%''>
                         <tr>
                              <td>
                                   Hubo un error aplicando el pago, por favor verifique los datos e int�ntelo de nuevo!<br>Admin info: " . mysql_error() . "
                              </td>
                         </tr>
                    </table>";
               
               }else{
                    
                    echo "<table width='100%''>
                         <tr style='background: yellow; color: Blue'>
                              <td>
                                   El pago ha sido efectuado correctamente.
                              </td>
                         </tr>
                    </table>";
               }
          }else{
               echo "<table width='100%''>
                    <tr>
                         <td>
                              Hubo un insertando el registro del pago en el log de pagos, por favor verifique los datos e int�ntelo de nuevo!<br>Admin info: " . mysql_error() . "
                         </td>
                    </tr>
               </table>";
          
          }
     }
?>
</form>
</Body>
</html>
