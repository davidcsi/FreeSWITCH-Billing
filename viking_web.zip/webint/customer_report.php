<?PHP

require "conexion.inc";
require "checklogin.inc";

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
	<title>Reporte por cliente</title>
	<link rel="stylesheet" href="pages_style.css">
</head>
<script language="javascript">
     function setdata(){
          tbl = document.getElementById('includedata').value;
          if(document.getElementById('includedata').value=="include"){
               document.getElementById('includedata').value="";
          }else{
               document.getElementById('includedata').value="include";
          }
     }


     function open_win(query)
     {
          window.open("export.php?filename=customer_report.csv&query=" + query + "");
     }
</script>

<script type="text/javascript" src="calendarDateInput.js">

/***********************************************
* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
* Script featured on and available at http://www.dynamicdrive.com
* Keep this notice intact for use.
***********************************************/
</script>
<body>
<h3>Reporte por cliente</h3>
<form action="customer_report.php" method="post">
<?
     if(!isset($_POST['customer'])){
?>
<table width=400px>
     <tr>
          <td>
               Cliente:
          </td>
          <td>
               <select id=customer name=customer>
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select ws_customer_symbol, ws_customer_company from ws_customers group by ws_customer_company order by ws_customer_company;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    while($linea=mysql_fetch_row($resultado)){                    	
                    	echo "<option value='" . $linea[0] . "'>" . $linea[1] . "</option>\n";
                    }
               ?>
               </select>
          </td>
     </tr>
     <tr>
          <td>
               Fechas Desde:
          </td>
          <td>
               <script>
                    DateInput('orderdate', true, 'YYYY-MM-DD')
               </script>
          </td>
     </tr>
     <tr>
          <td>
               Fechas Hasta:
          </td>
          <td>
               <script>
                    DateInput('orderdate2', true, 'YYYY-MM-DD')
               </script>
          </td>
     </tr>
     <tr>
          <td>
               <input type="submit" value="Ejecutar">
          </td>
          <td>
          </td>
     </tr>
</table>

<?

     }else{

          $host="192.168.168.2";
          $user="viking";
          $pass="V1k1ng";
          $db="viking";

          include 'asr_includes.php';
          $Query = "select customer_company as Customer, rate_areacode as Areacode, rate_description as Description, rate_rate as Rate, rate_gateway as Route, gw_symbol as Gateway, sum(billsec/60) as Minutes, sum(call_total_rate) as Sale, sum(call_total_cost) as Cost, sum(call_total_rate) - sum(call_total_cost) as Income from cdr where customer_symbol = '" . $_POST['customer'] . "' and datetime_start between '" . $_POST['orderdate'] . " 00:00:00' and '" . $_POST['orderdate2'] . " 23:59:59' group by customer_company, rate_areacode, rate_description, rate_rate, rate_gateway, gw_symbol order by customer_company, rate_areacode, rate_description, rate_rate, rate_gateway;";
          echo SQLResultTable($host,$user,$pass,$db,$Query);
?>

<button type="button" onClick="open_win('<?php echo urlencode($Query); ?>')">
       Export to CSV
</button>

<?php
     }
?>
</form>
</Body>
</html>
