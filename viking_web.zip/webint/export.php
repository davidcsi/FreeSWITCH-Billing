<?php

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"" . $_GET['filename'] . "\"");
require "conexion.inc";


$query = $_GET['query']; 

$Result = mysql_query($query) or die("Query failed : ($query) " . mysql_error()); 

$NumFields = mysql_num_fields ($Result);
for ($i=0; $i < $NumFields; $i++)
{
     echo mysql_field_name($Result, $i) . ";"; 
}
echo "\r\n";
      
while($Row = mysql_fetch_assoc ($Result))
{
     foreach($Row as $field => $value)
     {
          echo $value . ";";
     }
     echo "\r\n";
} 

?>
