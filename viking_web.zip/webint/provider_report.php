<?PHP

function displayLogin() {
header("WWW-Authenticate: Basic realm=\"Viking Management Platform\"");
header("HTTP/1.0 401 Unauthorized");
echo "<h2>Authentication Failure</h2>";
echo "La contrase�a que ha introducido no es v�lida. Refresque la p�gina e int�ntelo de nuevo.";
exit;
}

require "conexion.inc";
require "checklogin.inc";

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
	<title>Reporte por proveedor</title>
	<link rel="stylesheet" href="pages_style.css">
</head>
<script language="javascript">
     function setdata(){
          tbl = document.getElementById('includedata').value;
          if(document.getElementById('includedata').value=="include"){
               document.getElementById('includedata').value="";
          }else{
               document.getElementById('includedata').value="include";
          }
     }

     function open_win(query)
     {
          window.open("export.php?filename=provider_report.csv&query=" + query + "");
     }

</script>

<script type="text/javascript" src="calendarDateInput.js">

/***********************************************
* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
* Script featured on and available at http://www.dynamicdrive.com
* Keep this notice intact for use.
***********************************************/
</script>
<body>
<h3>Reporte por proveedor</h3>
<form action="provider_report.php" method="post">
<?
     if(!isset($_POST['provider'])){
?>
<table width=400px>
     <tr>
          <td>
               Proveedor:
          </td>
          <td>
               <select id=provider name=provider>
               <?php
                    // Check username and password agains the database.

                    $sqldatetime = "select symbol, name from ws_providers order by name;";
                    $resultado = mysql_query($sqldatetime) or die("La consulta ha fallado;: " . mysql_error());
                    
                    #	GET DATA SO THAT I CAN SHOW %/TOTAL FOR EACH CUSTOMER
                    while($linea=mysql_fetch_row($resultado)){                    	
                    	echo "<option value='" . $linea[0] . "'>" . $linea[1] . "</option>\n";
                    }
               ?>
               </select>
          </td>
     </tr>
     <tr>
          <td>
               Fechas Desde:
          </td>
          <td>
               <script>
                    DateInput('orderdate', true, 'YYYY-MM-DD')
               </script>
          </td>
     </tr>
     <tr>
          <td>
               Fechas Hasta:
          </td>
          <td>
               <script>
                    DateInput('orderdate2', true, 'YYYY-MM-DD')
               </script>
          </td>
     </tr>
     <tr>
          <td>
               <input type="submit" value="Ejecutar">
          </td>
          <td>
          </td>
     </tr>
</table>

<?

     }else{

          $host="192.168.168.2";
          $user="viking";
          $pass="V1k1ng";
          $db="viking";

          include 'asr_includes.php';
          $Query = "select gw_symbol, cost_areacode, cost_description, cost_cost, sum(billsec/60) as minutes, sum(call_total_rate) as venta, sum(call_total_cost) as coste from cdr where gw_symbol = '" . $_POST['provider'] . "' and datetime_start between '" . $_POST['orderdate'] . " 00:00:00' and '" . $_POST['orderdate2'] . " 23:59:59' group by gw_symbol, cost_areacode, cost_description, cost_cost order by gw_symbol, cost_areacode, cost_description, cost_cost ;";
          echo SQLResultTable($host,$user,$pass,$db,$Query);

?>
<button type="button" onClick="open_win('<?php echo urlencode($Query); ?>')">
       Export to CSV
</button>
<?php

     }
?>
</form>
</Body>
</html>
