<?php

require "../webint/conexion.inc";


echo "
";

$resultado_profiles = mysql_query("select service_ip, service_port, service_type from ws_settings") or die("La consulta ha fallado;: " . mysql_error());
while($linea_profile=mysql_fetch_row($resultado_profiles)){
     echo "
          <context name=\"$linea_profile[2]\">
          
               <extension name=\"unloop\">
                    <condition field=\"\$\${unroll_loops}\" expression=\"^true$\"/>
                    <condition field=\"\$\${sip_looped_call}\" expression=\"^true$\">
                         <action application=\"deflect\" data=\"\$\${destination_number}\"/>
                    </condition>
               </extension>
               
               <extension name=\"outside_call\" continue=\"true\">
                    <condition>
                         <action application=\"set\" data=\"outside_call=true\"/>
                    </condition>
               </extension>
               
               <extension name=\"hangup\">
                    <condition field=\"destination_number\" expression=\"^(hangup)\$\">
                         <action application=\"hangup\"/>
                    </condition>
               </extension>


               <!-- START OF DEBUGGING PER SESSION -->
               
";


     $resultado_trace = mysql_query("select remote_host, dialed_number from ws_settings where running_trace = 'YES';") or die("La consulta ha fallado;: " . mysql_error());
     while($linea_trace=mysql_fetch_row($resultado_trace)){
          $cnt++;
          $from_ip = str_replace(".","\.",$linea_trace[0]);
          $cldnum = $linea_trace[1];
          echo "
               <extension name=\"custom_debug\" continue=\"true\">
                    <condition field=\"network_addr\" expression=\"^" . $from_ip . "$\"/>
                    <condition field=\"destination_number\" expression=\"^" . $cldnum . "\$\">
                         <action application=\"session_loglevel\" data=\"debug\"/>
                    </condition>
               </extension>               
               
          ";
     }

     $resultado_prefix = mysql_query("select ws_customer_sig_ip, ws_customer_prefix from ws_customers where ws_customer_prefix is not null group by ws_customer_sig_ip, ws_customer_prefix order by ws_customer_sig_ip, ws_customer_prefix;") or die("La consulta ha fallado;: " . mysql_error());
     while($linea_prefix=mysql_fetch_row($resultado_prefix)){
          $cnt++;
          $ip = str_replace(".","\.",$linea_prefix[0]);
          echo "
               <!-- START OF PREFIX STRIPPING -->



               <extension name=\"remove_prefix_$cnt\" continue=\"true\">
                    <condition field=\"network_addr\" expression=\"^$ip\$\"/>
                    <condition field=\"destination_number\" expression=\"^$linea_prefix[1](\d+)\$\">
                              <action application=\"log\" data=\"Removing leading digits\"/>
                              <action application=\"set\" data=\"destination_number=\$1\"/>
                    </condition>
               </extension>
               
          ";
     }
echo "
               <!-- STOP OF PREFIX STRIPPING -->

               <extension name=\"wholesale\">
                    <condition field=\"destination_number\" expression=\"^.*\$\">
                         <action application=\"info\"/>
                        <action application=\"set\" data=\"inherit_codec=true\"/>
                         <action application=\"set\" data=\"hangup_after_bridge=true\"/>
                         <action application=\"lua\" data=\"/usr/local/freeswitch/scripts/script_wholesale.lua\"/>
                    </condition>
               </extension>
          
          
          </context>
     ";
}


?>

